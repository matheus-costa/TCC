# TCC
O Presente Software é uma aplicação web.  A mesma é desenvolvida na linguagem PHP no Front-End e também no Back-End, usando o PostgreSQL.
Este web site é um e-commerce no contexto do CIC(Centro de Integração Comercial), a aplicação
