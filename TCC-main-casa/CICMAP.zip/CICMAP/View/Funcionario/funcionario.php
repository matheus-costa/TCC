<p>
    <a href="cadastro_funcionario.php">Cadastrar de funcionarios</a>
    <a href="lista_funcionario.php">Lista de funcionarios</a>
</p>