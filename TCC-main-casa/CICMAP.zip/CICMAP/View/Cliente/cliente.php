<p>
    <a href="cadastro_cliente.php">Cadastrar de cliente</a>
    <a href="lista_cliente.php">Lista de clientes</a>
</p>