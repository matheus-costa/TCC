<p>
    <a href="cadastro_proprietario.php">Cadastrar Proprietários</a>
    <a href="lista_proprietario.php">Lista de Proprietários</a>
</p>