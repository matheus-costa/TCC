<p>
    <a href="cadastro_produto.php">Cadastrar de Produtos</a>
    <a href="lista_produto.php">Lista de Produtos</a>
</p>