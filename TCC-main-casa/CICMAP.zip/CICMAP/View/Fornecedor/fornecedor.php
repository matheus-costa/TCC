<p>
    <a href="cadastro_fornecedor.php">Cadastrar de fornecedores</a>
    <a href="lista_fornecedor.php">Lista de fornecedores</a>
</p>