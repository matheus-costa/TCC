<html>
    <head>
        <meta charset="utf-8"/>
        <body>
            <form action="../../Config/banca.php" method="POST">
                <fieldset>
                    <legend>Cadastro de Bancas</legend>
                    <p>Informe o nome da sua banca:<input type="text" name="nome" placeholder="Informe o nome da banca:" />
                    </p>
                    <p>Informe a numeração da sua banca:<input type="text" name="numero" placeholder="Informe a numeração da Banca:" />
                    </p>
                    <input type="submit" value="Cadastrar Banca"/></input>
                </fieldset>
            </form>
        </body>
    </head>
</html>