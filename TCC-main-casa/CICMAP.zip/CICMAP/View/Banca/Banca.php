<p>
    <a href="cadastro_banca.php">Cadastrar de Bancas</a>
    <a href="lista_banca.php">Lista de Bancas</a>
</p>