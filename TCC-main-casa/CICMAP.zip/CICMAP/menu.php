<p>
    <link rel="stylesheet" href="style.css">
    <a href="View/Banca/Banca.php">Banca</a>
    <a href="View/Cliente/cliente.php">Cliente</a>
    <a href="View/Fornecedor/fornecedor.php">Forecedores</a>
    <a href="View/Funcionario/funcionario.php">Funcionário</a>
    <a href="View/Produto/produto.php">Produto</a>
    <a href="View/Proprietario/proprietario.php">Proprietários</a>
</p>