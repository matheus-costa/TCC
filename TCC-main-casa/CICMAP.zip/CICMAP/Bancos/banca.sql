create table banca(

    id serial primary key,
    nome varchar,
    numeracao integer
);