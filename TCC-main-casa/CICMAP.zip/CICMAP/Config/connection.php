<?php 
   $conexao = new PDO('pgsql:host=localhost;port=5432;dbname=TCC;user= postgres;password=14122001');
?>